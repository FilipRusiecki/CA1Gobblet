var files_dup =
[
    [ "Gobblet", "dir_2bf293cb80de43e927f228afb54ae2a1.html", "dir_2bf293cb80de43e927f228afb54ae2a1" ]
];