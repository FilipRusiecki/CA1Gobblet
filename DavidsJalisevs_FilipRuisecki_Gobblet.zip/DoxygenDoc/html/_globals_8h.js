var _globals_8h =
[
    [ "MENU", "_globals_8h.html#adcd3ca3988491ccced1c1baf1e40b558", null ],
    [ "PLAY", "_globals_8h.html#a6713c6bdee79cef01d09cfd41f72ecae", null ]
];