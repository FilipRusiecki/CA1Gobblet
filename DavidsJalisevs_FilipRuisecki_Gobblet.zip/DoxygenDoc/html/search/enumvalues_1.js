var searchData=
[
  ['isgameover_0',['isGameOver',['../_game_state_8h.html#a7899b65f1ea0f655e4bbf8d2a5714285ab7332d2b91ea9d994324656959f73ad9',1,'GameState.h']]],
  ['ismovevalid_1',['isMoveValid',['../_game_state_8h.html#a7899b65f1ea0f655e4bbf8d2a5714285a9306c54926d0b0b623b9851aa1e23541',1,'GameState.h']]]
];
