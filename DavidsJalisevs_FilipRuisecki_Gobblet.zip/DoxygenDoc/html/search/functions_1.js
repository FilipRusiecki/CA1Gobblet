var searchData=
[
  ['cell_0',['Cell',['../class_cell.html#a394510643e8664cf12b5efaf5cb99f71',1,'Cell::Cell()'],['../class_cell.html#a5175a83dc89c4e3957d66736c756ba74',1,'Cell::Cell(sf::Vector2f t_position, int t_cellID, sf::Font &amp;t_font)']]]
];
