var searchData=
[
  ['setmarked_0',['setMarked',['../class_cell.html#ad388788c0f09627ed0997bf6f48a369e',1,'Cell']]],
  ['setprevious_1',['setPrevious',['../class_cell.html#a53c3232b17f1b08632fc715b118ed1a6',1,'Cell']]],
  ['setupgoblet_2',['setUpGoblet',['../class_a_i.html#af5319a49ce350be9ac0b6f49be97ebc2',1,'AI::setUpGoblet()'],['../class_player.html#ac1cb69128b745e0c9870a080d9a2e0ea',1,'Player::setUpGoblet()']]]
];
