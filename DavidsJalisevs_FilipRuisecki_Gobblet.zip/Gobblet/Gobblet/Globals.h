#pragma once

// used with the different modes in the game
const int MENU = 1;
const int PLAY = 2;		//CONTINUE SAVED GAME

